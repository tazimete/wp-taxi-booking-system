	<?php 

	/**
	Template Name: RDTS Notify Page
	**/

		get_header();

	?> 

	<div class="container">
		<?php echo the_content(); ?>
	</div>

	<?php 

		get_footer();


	?>